export interface user {
    email;
    password;
    name;
    surname;
    picture;
}