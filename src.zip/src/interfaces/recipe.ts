export interface recipe{
    name;
    ingredients;
    instructions;
    category;
    sub_category;
    serve;
    time;
}